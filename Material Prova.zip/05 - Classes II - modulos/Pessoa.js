class Pessoa{
    
    envelhecer(aumentaIdade){
        if(this.idade < 21){
            if( idade + aumentaIdade <=21){
                this.altura+=aumentaIdade
            }else{
                let aumentaAltura = 21 - this.idade
                this.altura = aumentaAltura;
            }
        }

        //aumentar a idade


    }
    
}


let p1 = new Pessoa("Joao",44,65, 1.7, )
let p2 = new Pessoa("Aylson", 33,77,1.82)
p1.cumprimenta(p2)
// imprime no console: Olá Aylson, meu nome é Joao, tudo certo?

//fusca com 30km/L de consumo médio
let fusca = new Carro("Fusca",30)
fusca.adicionarGasolina(50)
fusca.andar(100)
fusca.obterGasolina()


